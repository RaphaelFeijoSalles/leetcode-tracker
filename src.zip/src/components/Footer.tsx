import "./Footer.css";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-content">

        <p className="footer-title">
          © {new Date().getFullYear()} Raphael Salles
        </p>

        <div className="footer-buttons">
          <a href="mailto:feijoraphael1@gmail.com" className="footer-btn">Email</a>
          <a href="https://wa.me/55543999546030" target="_blank" className="footer-btn">WhatsApp</a>
          <a href="https://www.linkedin.com/in/raphaelfeijosalles/" target="_blank" className="footer-btn">LinkedIn</a>
          <a href="https://github.com/RaphaelFeijoSalles" target="_blank" className="footer-btn">GitHub</a>
        </div>

      </div>
    </footer>
  );
}
