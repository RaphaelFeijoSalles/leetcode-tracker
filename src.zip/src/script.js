const themeToggle = document.getElementById("theme-toggle");

function applyTheme() {
  const theme = localStorage.getItem("theme") || "light";

  if (theme === "dark") {
    document.body.classList.add("dark-theme");
    themeToggle.textContent = "☀️";
  } else {
    document.body.classList.remove("dark-theme");
    themeToggle.textContent = "🌙";
  }
}

themeToggle.addEventListener("click", () => {
  const current = localStorage.getItem("theme") || "light";
  const nextTheme = current === "light" ? "dark" : "light";
  localStorage.setItem("theme", nextTheme);
  applyTheme();
});

applyTheme();
